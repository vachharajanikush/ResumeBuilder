<?php
$con=mysqli_connect("localhost","root","","vinar");

// unm=$_POST['type']


$sql="select * from sub_categories order by sub_categories desc";
$res=mysqli_query($con,$sql);


$outp = $res->fetch_all(MYSQLI_ASSOC);
echo json_encode($outp);
?>