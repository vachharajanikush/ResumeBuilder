	<!-- <td class="product-name"><?php echo $row['added_on']?></td>
									<td class="product-name">
									<?php echo $row['address']?><br/>
									<?php echo $row['city']?><br/>
									<?php echo $row['pincode']?>
									</td>
									<td class="product-name"><?php echo $row['payment_type']?></td>
									<td class="product-name"><?php echo $row['payment_status']?></td>
									<td class="product-name"><?php echo $row['order_status_str']?></td>
									<td class="product-name">
									<?php 
									echo "Order Id:- ".$row['ship_order_id'].'<br/>';
									echo "Shipment Id:- ".$row['ship_shipment_id'];
									
									?></td> -->




									<a href="../order_pdf.php?id=<?php echo $row['id']?>">PDF</a></td>
									<td class="product-name"><?php echo $row['added_on']?></td>
									<td class="product-name">
									<?php echo $row['address']?><br/>
									<?php echo $row['city']?><br/>
									<?php echo $row['pincode']?>
									</td>
									<td class="product-name"><?php echo $row['payment_type']?></td>
									<td class="product-name"><?php echo $row['payment_status']?></td>
									<td class="product-name"><?php echo $row['order_status_str']?></td>
									<td class="product-name">
									<?php 
									echo "Order Id:- ".$row['ship_order_id'].'<br/>';
									echo "Shipment Id:- ".$row['ship_shipment_id'];
									
									?></td>
									<td class="serial"><?php echo $i?></td>


