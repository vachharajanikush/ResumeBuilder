<?php
$con=mysqli_connect("localhost","root","","vinar");

// unm=$_POST['type']


$sql="select * from product order by product desc";
$res=mysqli_query($con,$sql);


$outp = $res->fetch_all(MYSQLI_ASSOC);
echo json_encode($outp);
?>