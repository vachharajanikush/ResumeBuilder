<?php
session_start();
$con=mysqli_connect("localhost","id18474540_dhyey","Admin@123456","id18474540_vinar");
//$con=mysqli_connect("localhost","root","","vinar");
define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'\VINAR_ADMIN_PANEL\admin');
define('SITE_PATH','https://in.000webhost.com/members/website/vinarjewellersmart/database');

define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'media/product/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'media/product/');
?>