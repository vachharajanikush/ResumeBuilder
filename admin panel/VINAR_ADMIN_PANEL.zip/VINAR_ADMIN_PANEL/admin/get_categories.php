<?php
require('top.inc.php'); 
 $stmt = $con->prepare("SELECT * FROM categories");
 $stmt->execute();
$result = $stmt->get_result();
$outp = $result->fetch_all(MYSQLI_ASSOC);
echo json_encode($outp);
?>